# Chấm Công — Flutter starter

App chấm công lịch tháng cho Android và iOS.

## Đã có
- Lịch tháng, chuyển tháng trước/sau.
- Chạm ngày để đánh dấu/bỏ đánh dấu ngày công.
- Nhập lương một ngày trong mục Cài đặt (biểu tượng bánh răng); bấm Lưu để cập nhật tổng lương.
- Thanh tổng quan: tháng/năm, số ngày công, tiền lương.
- Lưu dữ liệu cục bộ trên máy bằng SharedPreferences.

## Chạy thử
Cần cài Flutter SDK và Android Studio (Android). Với iOS, cần macOS + Xcode.

```bash
flutter pub get
flutter run
```

## Build Android APK
```bash
flutter build apk --release
```

## Build iOS
Trên macOS:
```bash
flutter build ios --release
```

Ghi chú: Đây là mã nguồn Flutter, chưa phải file APK/IPA đã build.
